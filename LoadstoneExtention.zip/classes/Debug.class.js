
class Debug {
	static log (value) {
		console.log (value);
	}
}